package com.fdmgroupCharityDatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CharityDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CharityDatabaseApplication.class, args);
	}

}
