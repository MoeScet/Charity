package com.fdmgroupCharityDatabase.Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AgentTest {

	@Test
	void testAgentStringStringString() {
		fail("Not yet implemented");
	}

	@Test
	void testAgent() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAgentId() {
		fail("Not yet implemented");
	}

	@Test
	void testSetAgentId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPassword() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPassword() {
		fail("Not yet implemented");
	}

}
